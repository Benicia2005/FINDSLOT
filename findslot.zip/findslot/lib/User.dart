import 'package:flutter/material.dart';
import 'package:findslot/secondpage.dart';
import 'package:findslot/usereditpage.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:findslot/wallet.dart';

import 'bookingpage.dart';
import 'common.dart';
import 'edituser.dart';


class UserHomePage extends StatefulWidget {
  const UserHomePage({super.key});

  @override
  State<UserHomePage> createState() => _UserHomePageState();
}

class _UserHomePageState extends State<UserHomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
     UserHome(),
    UserHistoryPage(), // Partner History
    UserProfile(), // Partner Profile
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        backgroundColor: Colors.purple,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}


class UserHome extends StatefulWidget {
  // Accepting email for balance fetching



  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _parkingSlots = [];
  List<Map<String, dynamic>> _filteredSlots = [];
  int _balance = 0; // To store user's wallet balance

  @override
  void initState() {
    super.initState();
    _fetchParkingSlots();
    _fetchBalance(); // Fetch balance when the page loads
  }

  Future<void> _fetchParkingSlots() async {
    final response = await http.get(Uri.parse(ip + 'userhome.php'));
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          _parkingSlots = List<Map<String, dynamic>>.from(data['lands']);
          _filteredSlots = _parkingSlots;
        });
      }
    }
  }

  Future<void> _fetchBalance() async {
    final response = await http.post(
      Uri.parse(ip + 'userbal.php'), // Replace with correct endpoint
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": id}),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          _balance = data['balance']; // Update balance
        });
      }
    }
  }

  void _filterSlots(String query) {
    setState(() {
      _filteredSlots = _parkingSlots.where((slot) {
        final name = slot['slotname'].toLowerCase();
        final area = slot['area'].toLowerCase();
        return name.contains(query.toLowerCase()) || area.contains(query.toLowerCase());
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Row(
          children: [
            const Icon(Icons.wallet, color: Colors.white),
            const SizedBox(width: 8),
            Text("₹$_balance", style: const TextStyle(color: Colors.white)), // Updated balance display
            IconButton(
              icon: const Icon(Icons.add_circle, color: Colors.white),
              onPressed: () async {
                // Push the WalletPage, and when it returns true, refresh balance
                final didUpdate = await Navigator.push<bool>(
                  context,
                  MaterialPageRoute(builder: (_) => const WalletPage()),
                );
                if (didUpdate == true) {
                  _fetchBalance();
                }
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              onChanged: _filterSlots,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                hintText: "SEARCH AREA OR PARKING",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _filteredSlots.length,
                itemBuilder: (context, index) {
                  final parking = _filteredSlots[index];
                  return GestureDetector(
                    onTap: () {
                      land = parking["email"];
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BookingPage(),
                        ),
                      );
                    },
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      margin: const EdgeInsets.only(bottom: 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10),
                            ),
                            child: Image.network(
                              ip + parking['image'],
                              height: 180,
                              width: double.infinity,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) => Container(
                                height: 180,
                                color: Colors.grey[300],
                                child: const Icon(Icons.image_not_supported, size: 50, color: Colors.grey),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  parking['slotname'],
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  "Location: ${parking['area']}",
                                  style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                                ),
                                const SizedBox(height: 4),
                                Text("🚲 Bike Slots: ${parking['no_of_bike_slot_available']}", style: const TextStyle(fontSize: 14)),
                                Text("🚗 Car Slots: ${parking['no_of_car_slot_available']}", style: const TextStyle(fontSize: 14)),
                                Text("💰 Bike Cost: ₹${parking['bike_cost']} / hr", style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                                Text("💰 Car Cost: ₹${parking['car_cost']} / hr", style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class UserProfile extends StatefulWidget {
  @override
  _UserProfileState createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController altPhoneController = TextEditingController(text: "upi8008017003");

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchUserProfile();
  }

  Future<void> fetchUserProfile() async {
    String url = ip + "userprofile.php"; // Your PHP API URL

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"email": id}),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        if (data["status"] == "success") {
          setState(() {
            nameController.text = data["user"]["name"];
            phoneController.text = data["user"]["mobilenumber"].toString();
            emailController.text = data["user"]["email"];
            isLoading = false;
          });
        } else {
          showError("User not found");
        }
      } else {
        showError("Server error: ${response.statusCode}");
      }
    } catch (e) {
      showError("Error fetching profile: $e");
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  void _showLogoutPopup() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Logout Confirmation"),
          content: const Text("Are you sure you want to logout?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => UserPage())); // Replace with your login route
              },
              child: const Text("Logout", style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, IconData icon) {
    return TextField(
      controller: controller,
      readOnly: true,
      style: TextStyle(color: Colors.white),
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white10,
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white70),
        prefixIcon: Icon(icon, color: Colors.white),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("User Profile", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.purple,
        actions: [
          IconButton(
            icon: Icon(Icons.logout, color: Colors.white),
            onPressed: _showLogoutPopup,
          ),
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: Colors.purple))
          : Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.purple, width: 2),
              ),
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.white,
                child: Icon(Icons.person, size: 60, color: Colors.purple),
              ),
            ),
            SizedBox(height: 15),
            Text("Your Information", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            _buildTextField(nameController, "Full Name", Icons.person),
            SizedBox(height: 10),
            _buildTextField(phoneController, "Phone Number", Icons.phone),
            SizedBox(height: 10),
            _buildTextField(emailController, "Email", Icons.email),
            SizedBox(height: 80),

            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EditUserPage(
                      name: nameController.text,
                      phone: phoneController.text,
                      email: emailController.text,
                    ),
                  ),
                );

                if (result != null) {
                  setState(() {
                    nameController.text = result["name"];
                    phoneController.text = result["phone"];
                    emailController.text = result["email"];
                  });
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                minimumSize: Size(double.infinity, 50),
              ),
              child: Text("EDIT PROFILE", style: TextStyle(fontSize: 18, color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}

  Widget _buildTextField(TextEditingController controller) {
    return TextField(
      controller: controller,
      readOnly: true,
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.black),
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }





class UserHistoryPage extends StatefulWidget {
  const UserHistoryPage({Key? key}) : super(key: key);

  @override
  State<UserHistoryPage> createState() => _UserHistoryPageState();
}

class _UserHistoryPageState extends State<UserHistoryPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<Map<String, dynamic>> pendingBookings = [];
  List<Map<String, dynamic>> inBookings = [];
  List<Map<String, dynamic>> outBookings = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    fetchUserHistory();
  }

  Future<void> fetchUserHistory() async {
    final url = Uri.parse('$ip/userhistory.php');
    try {
      final resp = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': id}),
      );

      if (resp.statusCode != 200) {
        throw 'Server error: ${resp.statusCode}';
      }

      final Map<String, dynamic> data = jsonDecode(resp.body);
      if (data['status'] != 'success') {
        throw data['message'] ?? 'Unknown error';
      }

      setState(() {
        pendingBookings = List<Map<String, dynamic>>.from(data['pending']);
        inBookings      = List<Map<String, dynamic>>.from(data['in']);
        outBookings     = List<Map<String, dynamic>>.from(data['out']);
      });
    } catch (e) {
      print('Error fetching history: $e');
    }
  }

  void _showQRCodePopup(String qrUrl) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('QR Code'),
        content: Image.network(qrUrl, width: 200, height: 200, fit: BoxFit.cover),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))
        ],
      ),
    );
  }

  Widget buildHistoryList(List<Map<String, dynamic>> list, String status) {
    if (list.isEmpty) {
      return const Center(
        child: Text('No records available', style: TextStyle(color: Colors.white)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      itemCount: list.length,
      itemBuilder: (ctx, i) {
        final h = list[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ** Booking ID **
                Text('Booking ID: ${h['booking_id']}',
                    style: const TextStyle(color: Colors.grey, fontSize: 13)),
                const SizedBox(height: 6),

                Row(
                  children: [
                    const CircleAvatar(
                      backgroundColor: Colors.black12,
                      child: Icon(Icons.local_parking, color: Colors.black),
                    ),
                    const SizedBox(width: 10),
                    Text(h['land'],
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 8),

                Text('Vehicle: ${h['vehicle_type']}'),
                if (status != 'pending') Text('In Time: ${h['in_time']}'),
                if (status == 'out') ...[
                  Text('Out Time: ${h['out_time']}'),
                  Text('Cost: ₹${h['cost']}'),
                ],

                // only show the button for 'pending' and 'in' statuses
                if (status != 'out') ...[
                  const SizedBox(height: 10),
                  Center(
                    child: ElevatedButton(
                      onPressed: () => _showQRCodePopup('$ip/${h['qr_code_path']}'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: status == 'pending'
                            ? Colors.blue
                            : Colors.green,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                      ),
                      child: Text(status.toUpperCase()),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    appBar: AppBar(
      backgroundColor: Colors.purple,
      title: const Text('User History'),
      bottom: TabBar(
        controller: _tabController,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.white70,
        indicatorColor: Colors.white,
        tabs: const [
          Tab(text: 'Pending',),
          Tab(text: 'Checked-in'),
          Tab(text: 'Checked-out'),
        ],
      ),
    ),
    body: TabBarView(
      controller: _tabController,
      children: [
        buildHistoryList(pendingBookings, 'pending'),
        buildHistoryList(inBookings, 'in'),
        buildHistoryList(outBookings, 'out'),
      ],
    ),
  );
}
