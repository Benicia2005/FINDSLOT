import 'package:flutter/material.dart';
import 'package:findslot/partnerlogin.dart';
import 'package:findslot/userloginpage.dart';

import 'adminlogin.dart';

class UserPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          SizedBox(height: 50),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
            child: Image.asset(
              'assets/park.png', // Replace with your actual asset path
              height: 200,
            ),
          ),
          SizedBox(height: 40),
          UserOption(
            iconPath: 'assets/admn.png',
            label: 'Admin',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AdminLoginPage()),
              );
            },
          ),
          SizedBox(height: 30),
          UserOption(
            iconPath: 'assets/pat.png',
            label: 'Partner',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => PartnerLoginPage()),
              );
            },
          ),
          SizedBox(height: 30),
          UserOption(
            iconPath: 'assets/usr.png',
            label: 'User',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => UserLoginPage()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class UserOption extends StatelessWidget {
  final String iconPath;
  final String label;
  final VoidCallback onTap;

  UserOption({
    required this.iconPath,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 400,
        padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Image.asset(
              iconPath,
              height: 40,
              color: Colors.purple,
            ),
            SizedBox(width: 20),
            Text(
              label,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}






