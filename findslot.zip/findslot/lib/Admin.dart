import 'package:findslot/requestdetailspage.dart';
import 'package:findslot/secondpage.dart';
import 'package:flutter/material.dart';

import 'dart:convert';
import 'package:http/http.dart' as http;

import 'common.dart';
class Admin extends StatefulWidget {
  @override
  _AdminState createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  int _selectedIndex = 0; // Bottom Nav Index

  // Controllers for dynamic data
  final TextEditingController usersController = TextEditingController(text: "2");
  final TextEditingController parkingOwnersController = TextEditingController(text: "3");
  final TextEditingController pendingRequestsController = TextEditingController(text: "2");

  // Pages
  final List<Widget> _pages = [
    AdminHome(),
    AdminRequest(),
    AdminHistory(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.purple,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.request_page),
            label: "Request",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: "History",
          ),
        ],
      ),
    );
  }
}



class AdminHome extends StatefulWidget {
  @override
  _AdminHomeState createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  String totalUsers = "";
  String totalParking = "";
  String totalPending = "";

  @override
  void initState() {
    super.initState();
    fetchAdminData();
  }

  Future<void> fetchAdminData() async {
    final response = await http.post(Uri.parse(ip+'adminhome.php'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          print(data.toString());
          totalUsers = data['total_no_of_users'];
          totalParking = data['total_no_of_parking'];
          totalPending = data['total_no_of_pending'];
        });
      }
    }
  }

  void _showLogoutPopup() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Logout Confirmation"),
          content: const Text("Are you sure you want to logout?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => UserPage())); // Replace with your login route
              },
              child: const Text("Logout", style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar:  AppBar(
        backgroundColor: Colors.purple,
        title: const Text("Admin", style: TextStyle(color: Colors.white)),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildCard("Number of Users", totalUsers.toString()),
                _buildCard("No of Parking\nowners", totalParking.toString()),
              ],
            ),
            SizedBox(height: 20),
            _buildCard("Number of Pending Requests", totalPending.toString(), isFullWidth: true),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(String title, String value, {bool isFullWidth = false}) {
    return SizedBox(
      width: isFullWidth ? double.infinity : null,
      height: 150,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: isFullWidth ? 0 : 5, vertical: 5),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}


class AdminRequest extends StatefulWidget {
  @override
  _AdminRequestState createState() => _AdminRequestState();
}

class _AdminRequestState extends State<AdminRequest> {
  List<Map<String, dynamic>> parkingRequests = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchRequests();
  }

  Future<void> fetchRequests() async {
    final response = await http.post(Uri.parse(ip + "adminrequest.php"));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      setState(() {
        if (data["status"] == "success" && data["lands"] != null) {
          parkingRequests = List<Map<String, dynamic>>.from(data["lands"]);
        }
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  void navigateToNextPage(String email) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AdminRequestDetails(email: email),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text("Admin", style: TextStyle(color: Colors.white)),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : parkingRequests.isEmpty
          ? Center(
        child: Text(
          "No request available",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(10),
        itemCount: parkingRequests.length,
        itemBuilder: (context, index) {
          var request = parkingRequests[index];
          return GestureDetector(
            onTap: () => navigateToNextPage(request["email"]),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        ip + request["image"],
                        width: double.infinity,
                        height: 150,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) =>
                            Icon(Icons.image_not_supported,
                                size: 100),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      request["slotname"],
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 5),
                    Text("Area: ${request["area"]}",
                        style: const TextStyle(fontSize: 14)),
                    Text("Email: ${request["email"]}",
                        style: const TextStyle(
                            fontSize: 14, color: Colors.grey)),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}




class AdminHistory extends StatefulWidget {
  @override
  _AdminHistoryState createState() => _AdminHistoryState();
}

class _AdminHistoryState extends State<AdminHistory> {
  List<Map<String, dynamic>> historyRequests = [];
  bool isLoading = true;
  bool hasError = false;

  @override
  void initState() {
    super.initState();
    fetchHistory();
  }

  Future<void> fetchHistory() async {
    final String apiUrl = ip+"adminhistory.php";

    try {
      final response = await http.post(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);

        if (data["status"] == "success") {
          setState(() {
            historyRequests = List<Map<String, dynamic>>.from(data["lands"]);
            isLoading = false;
          });
        } else {
          setState(() {
            hasError = true;
            isLoading = false;
          });
        }
      } else {
        setState(() {
          hasError = true;
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        hasError = true;
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Text("Admin", style: TextStyle(color: Colors.white)),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : hasError
          ? Center(child: Text("Failed to load data", style: TextStyle(color: Colors.red)))
          : historyRequests.isEmpty
          ? Center(child: Text("No data available"))
          : ListView.builder(
        padding: EdgeInsets.all(10),
        itemCount: historyRequests.length,
        itemBuilder: (context, index) {
          var request = historyRequests[index];
          return Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      ip+request["image"],
                      width: double.infinity,
                      height: 150,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Icon(Icons.broken_image, size: 100, color: Colors.grey),
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    request["slotname"],
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 5),
                  Text("Area: ${request["area"]}", style: TextStyle(fontSize: 14)),
                  Text("Email: ${request["email"]}", style: TextStyle(fontSize: 14, color: Colors.grey)),
                  Text("Bike Slots: ${request["no_of_slots_for_bike"]}", style: TextStyle(fontSize: 14)),
                  Text("Car Slots: ${request["no_of_slots_for_car"]}", style: TextStyle(fontSize: 14)),
                  Text("Bike Cost: ${request["bike_cost"]}", style: TextStyle(fontSize: 14)),
                  Text("Car Cost: ${request["car_cost"]}", style: TextStyle(fontSize: 14)),
                  Text(
                    "Status: ${request["status"]}",
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        color: request["status"] == "approved" ? Colors.green : Colors.red,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Text(
                        request["status"].toUpperCase(),
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
