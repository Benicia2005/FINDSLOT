import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'common.dart';

class AdminRequestDetails extends StatefulWidget {
  final String email;
  AdminRequestDetails({required this.email});

  @override
  _AdminRequestDetailsState createState() => _AdminRequestDetailsState();
}

class _AdminRequestDetailsState extends State<AdminRequestDetails> {
  Map<String, dynamic>? landDetails;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchLandDetails();
  }

  Future<void> fetchLandDetails() async {
    final response = await http.post(
      Uri.parse(ip + "requestdetails.php"),
      body: {"email": widget.email},
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data["status"] == "success") {
        setState(() {
          landDetails = data["land_details"];
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> updateLandStatus(String status, {String? reason}) async {
    final response = await http.post(
      Uri.parse(ip + "requestresponse.php"),
      body: {
        "email": widget.email,
        "status": status,
        "reason": reason ?? "",
      },
    );

    final data = json.decode(response.body);
    if (data["status"] == "success") {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(data["message"])),
      );
      Navigator.pop(context); // Go back after update
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to update status")),
      );
    }
  }

  void _showRejectionPopup() {
    TextEditingController reasonController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          title: const Text("Enter the reason for rejection"),
          content: TextField(
            controller: reasonController,
            decoration: const InputDecoration(
              hintText: "Type your reason here...",
              border: OutlineInputBorder(),
            ),
            maxLines: 3,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context), // Close popup
              child: const Text("Cancel", style: TextStyle(color: Colors.red)),
            ),
            ElevatedButton(
              onPressed: () {
                String reason = reasonController.text.trim();
                if (reason.isNotEmpty) {
                  updateLandStatus("rejected", reason: reason);
                  Navigator.pop(context); // Close popup
                }
              },
              child: const Text("Submit"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text("Request Details", style: TextStyle(color: Colors.white)),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : landDetails == null
          ? Center(child: Text("No details found", style: TextStyle(fontSize: 18)))
          : Padding(
        padding: const EdgeInsets.all(12),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Land Image
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  ip + landDetails!["image"],
                  width: double.infinity,
                  height: 200,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      Icon(Icons.image_not_supported, size: 100),
                ),
              ),
              const SizedBox(height: 10),

              // Slot Name
              Text(
                landDetails!["slotname"],
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 5),

              // Area
              Text("Area: ${landDetails!["area"]}", style: TextStyle(fontSize: 16)),

              // Slots and Cost Info
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _infoCard("Bike Slots", landDetails!["no_of_slots_for_bike"]),
                  _infoCard("Car Slots", landDetails!["no_of_slots_for_car"]),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _infoCard("Bike Cost", landDetails!["bike_cost"]),
                  _infoCard("Car Cost", landDetails!["car_cost"]),
                ],
              ),
              const SizedBox(height: 10),

              // Proof Image
              Text("Ownership Proof", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  ip + landDetails!["proof"],
                  width: double.infinity,
                  height: 200,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      Icon(Icons.image_not_supported, size: 100),
                ),
              ),

              const SizedBox(height: 20),

              // Approve & Reject Buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: () {
                      updateLandStatus("approved", reason: null);
                    },
                    icon: Icon(Icons.check, color: Colors.white),
                    label: Text("Approve"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: _showRejectionPopup,
                    icon: Icon(Icons.close, color: Colors.white),
                    label: Text("Reject"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoCard(String title, dynamic value) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text(value.toString(), style: TextStyle(fontSize: 16, color: Colors.purple)),
          ],
        ),
      ),
    );
  }
}
