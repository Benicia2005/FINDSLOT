import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'common.dart'; // Assuming this contains your 'ip' variable

class QRScannerPageOUT extends StatefulWidget {
  @override
  _QRScannerPageINState createState() => _QRScannerPageINState();
}

class _QRScannerPageINState extends State<QRScannerPageOUT> {
  String? scannedResult;
  MobileScannerController cameraController = MobileScannerController();
  bool isProcessing = false;
  String? responseMessage;
  bool isSuccess = false;

  @override
  void dispose() {
    cameraController.dispose();
    super.dispose();
  }

  Future<void> updateInTime(String qrData) async {
    setState(() {
      isProcessing = true;
      responseMessage = null;
      isSuccess = false;
    });

    try {
      // Extract booking ID from QR data
      // Assuming the QR format is "BOOKING_ID:123"
      String bookingId = "";
      if (qrData.contains("BOOKING_ID:")) {
        bookingId = qrData.split("BOOKING_ID:")[1].trim();
      } else {
        // If the QR code doesn't match expected format, try to use it directly
        bookingId = qrData;
      }

      final response = await http.post(
        Uri.parse(ip + "slot_out.php"), // Update to your PHP file name
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": bookingId}),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        setState(() {
          isProcessing = false;
          responseMessage = data['message'];
          isSuccess = data['status'] == 'success';
        });
      } else {
        setState(() {
          isProcessing = false;
          responseMessage = "Server error. Please try again later.";
          isSuccess = false;
        });
      }
    } catch (e) {
      setState(() {
        isProcessing = false;
        responseMessage = "Error: ${e.toString()}";
        isSuccess = false;
      });
    }
  }

  void processQRCode(String qrData) {
    setState(() {
      scannedResult = qrData;
    });

    // Pause scanning once a QR code is detected
    cameraController.stop();
  }

  void showAlert(String title, String message, bool isSuccess) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          backgroundColor: isSuccess ? Colors.green[50] : Colors.red[50],
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                if (isSuccess) {
                  // Optionally navigate back or to another page on success
                  // Navigator.of(context).pop();
                } else {
                  // Reset scanner for another attempt
                  cameraController.start();
                }
              },
              child: const Text("OK"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Scan QR Code"),
        backgroundColor: Colors.purple,
        actions: [
          IconButton(
            icon: const Icon(Icons.flash_on, color: Colors.white),
            onPressed: () {
              cameraController.toggleTorch();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 4,
            child: Stack(
              alignment: Alignment.center,
              children: [
                MobileScanner(
                  controller: cameraController,
                  onDetect: (capture) {
                    final List<Barcode> barcodes = capture.barcodes;
                    if (barcodes.isNotEmpty && !isProcessing && responseMessage == null) {
                      final String qrValue = barcodes.first.rawValue ?? "No QR Code detected";
                      processQRCode(qrValue);
                    }
                  },
                ),
                Positioned(
                  top: 100,
                  child: Column(
                    children: [
                      const Text(
                        "Align the QR code inside the frame",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        width: 200,
                        height: 200,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.green, width: 3),
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                    ],
                  ),
                ),
                if (isProcessing)
                  Container(
                    color: Colors.black54,
                    child: const Center(
                      child: CircularProgressIndicator(color: Colors.purple),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Column(
              children: [
                if (scannedResult != null)
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(
                      "Scanned: $scannedResult",
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ),
                if (responseMessage != null)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      responseMessage!,
                      style: TextStyle(
                        color: isSuccess ? Colors.green : Colors.red,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ElevatedButton(
                  onPressed: isProcessing
                      ? null
                      : () {
                    if (scannedResult != null) {
                      updateInTime(scannedResult!);
                    } else {
                      cameraController.start();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text(
                    scannedResult == null ? "Scan QR Code" : "Update Out-Time",
                    style: const TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
                if (scannedResult != null)
                  TextButton(
                    onPressed: () {
                      setState(() {
                        scannedResult = null;
                        responseMessage = null;
                      });
                      cameraController.start();
                    },
                    child: const Text("Scan Again", style: TextStyle(color: Colors.white)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}