import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'common.dart';

class EditPartnerPage extends StatefulWidget {
  final Map<String, dynamic> landDetails;

  EditPartnerPage({required this.landDetails});

  @override
  _EditPartnerPageState createState() => _EditPartnerPageState();
}

class _EditPartnerPageState extends State<EditPartnerPage> {
  late TextEditingController slotNameController;
  late TextEditingController areaController;
  late TextEditingController bikeSlotsController;
  late TextEditingController carSlotsController;
  late TextEditingController bikeCostController;
  late TextEditingController carCostController;
  late TextEditingController mapLinkController;

  @override
  void initState() {
    super.initState();
    slotNameController = TextEditingController(text: widget.landDetails["slotname"]);
    areaController = TextEditingController(text: widget.landDetails["area"]);
    bikeSlotsController = TextEditingController(text: widget.landDetails["no_of_slots_for_bike"].toString());
    carSlotsController = TextEditingController(text: widget.landDetails["no_of_slots_for_car"].toString());
    bikeCostController = TextEditingController(text: widget.landDetails["bike_cost"].toString());
    carCostController = TextEditingController(text: widget.landDetails["car_cost"].toString());
    mapLinkController = TextEditingController(text: widget.landDetails["map_link"]);
  }

  Future<void> _saveChanges() async {
    final url = Uri.parse(ip+"editpartner.php"); // Replace with your API endpoint
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "email": id,
        "slotname": slotNameController.text,
        "area": areaController.text,
        "no_of_slots_for_bike": int.tryParse(bikeSlotsController.text) ?? 0,
        "no_of_slots_for_car": int.tryParse(carSlotsController.text) ?? 0,
        "bike_cost": double.tryParse(bikeCostController.text) ?? 0.0,
        "car_cost": double.tryParse(carCostController.text) ?? 0.0,
        "map_link": mapLinkController.text,
      }),
    );

    if (response.statusCode == 200) {
      final result = jsonDecode(response.body);
      if (result["status"] == "success") {
        Navigator.pop(context, {
          "slotname": slotNameController.text,
          "area": areaController.text,
          "no_of_slots_for_bike": bikeSlotsController.text,
          "no_of_slots_for_car": carSlotsController.text,
          "bike_cost": bikeCostController.text,
          "car_cost": carCostController.text,
          "map_link": mapLinkController.text,
        });
      } else {
        _showMessage(result["message"]);
      }
    } else {
      _showMessage("Failed to update. Please try again later.");
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Edit Partner Details"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildTextField("Slot Name", slotNameController),
              _buildTextField("Area", areaController),
              _buildTextField("Bike Slots", bikeSlotsController, isNumber: true),
              _buildTextField("Car Slots", carSlotsController, isNumber: true),
              _buildTextField("Bike Cost", bikeCostController, isNumber: true),
              _buildTextField("Car Cost", carCostController, isNumber: true),
              _buildTextField("Map Link", mapLinkController),
              SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: _saveChanges,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      minimumSize: Size(150, 50),
                    ),
                    child: Text("SAVE", style: TextStyle(fontSize: 18, color: Colors.white)),
                  ),
                  ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      minimumSize: Size(150, 50),
                    ),
                    child: Text("CANCEL", style: TextStyle(fontSize: 18, color: Colors.white)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller, {bool isNumber = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        style: TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.white),
          filled: true,
          fillColor: Colors.grey[800],
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}
