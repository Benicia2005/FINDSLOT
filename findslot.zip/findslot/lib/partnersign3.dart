import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:findslot/partnerlogin.dart';

import 'common.dart';

class RegisterParking2 extends StatefulWidget {
  final String name;
  final String email;
  final String password;
  final String mobile;
  final String parkingName;
  final String area;
  final String bikeSlots;
  final String carSlots;
  final String bikeCost;
  final String carCost;
  final String gmapLink;

  RegisterParking2({
    required this.name,
    required this.email,
    required this.password,
    required this.mobile,
    required this.parkingName,
    required this.area,
    required this.bikeSlots,
    required this.carSlots,
    required this.bikeCost,
    required this.carCost,
    required this.gmapLink,
  });

  @override
  _RegisterParking2State createState() => _RegisterParking2State();
}

class _RegisterParking2State extends State<RegisterParking2> {
  XFile? landProof;
  XFile? parkingImage;
  final ImagePicker picker = ImagePicker();
  bool isLoading = false;

  Future<void> pickImage(bool isLandProof) async {
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        if (isLandProof) {
          landProof = image;
        } else {
          parkingImage = image;
        }
      });
    }
  }

  Future<void> submitParkingRegistration() async {
    if (landProof == null || parkingImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please upload all required images")),
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    // Create multipart request
    var request = http.MultipartRequest(
      'POST',
      Uri.parse(ip+'partnerregister.php'),
    );

    // Add text fields
    request.fields['name'] = widget.name;
    request.fields['email'] = widget.email;
    request.fields['password'] = widget.password;
    request.fields['mobilenumber'] = widget.mobile;
    request.fields['slotname'] = widget.parkingName;
    request.fields['area'] = widget.area;
    request.fields['no_of_slots_for_bike'] = widget.bikeSlots;
    request.fields['no_of_slots_for_car'] = widget.carSlots;
    request.fields['bike_cost'] = widget.bikeCost;
    request.fields['car_cost'] = widget.carCost;
    request.fields['map_link'] = widget.gmapLink;

    // Add files
    request.files.add(
      http.MultipartFile(
        'proof',
        File(landProof!.path).readAsBytes().asStream(),
        File(landProof!.path).lengthSync(),
        filename: landProof!.path.split('/').last,
      ),
    );

    request.files.add(
      http.MultipartFile(
        'image',
        File(parkingImage!.path).readAsBytes().asStream(),
        File(parkingImage!.path).lengthSync(),
        filename: parkingImage!.path.split('/').last,
      ),
    );

    try {
      // Send request
      var response = await request.send();

      // Get response
      final respStr = await response.stream.bytesToString();

      setState(() {
        isLoading = false;
      });

      if (response.statusCode == 200) {
        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Registration successful!")),
        );

        // Navigate to login page
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => PartnerLoginPage(),
          ),
        );
      } else {
        // Show error message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Registration failed. Please try again.")),
        );
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });

      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Text("Register Parking", style: TextStyle(color: Colors.white)),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        color: Colors.black,
        width: double.infinity,
        padding: EdgeInsets.all(16),
        child: isLoading
            ? Center(child: CircularProgressIndicator(color: Colors.purple))
            : Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            uploadSection("Upload Land Proof", landProof, () => pickImage(true)),
            SizedBox(height: 40),
            uploadSection("Upload Parking Image", parkingImage, () => pickImage(false)),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: submitParkingRegistration,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                padding: EdgeInsets.symmetric(vertical: 14, horizontal: 32),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text("Register Parking", style: TextStyle(fontSize: 16, color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  Widget uploadSection(String title, XFile? image, VoidCallback onTap) {
    return Column(
      children: [
        Text(title, style: TextStyle(color: Colors.white, fontSize: 16)),
        SizedBox(height: 10),
        GestureDetector(
          onTap: onTap,
          child: Container(
            height: 80,
            width: 80,
            decoration: BoxDecoration(
              color: Colors.grey[800],
              borderRadius: BorderRadius.circular(10),
            ),
            child: image == null
                ? Icon(Icons.insert_drive_file, size: 50, color: Colors.grey)
                : Image.file(
              File(image.path),
              fit: BoxFit.cover,
            ),
          ),
        ),
      ],
    );
  }
}