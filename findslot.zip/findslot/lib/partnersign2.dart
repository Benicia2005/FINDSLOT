import 'package:flutter/material.dart';
import 'package:findslot/partnersign3.dart';

class RegisterParkingPage extends StatefulWidget {
  final String name, email, password, mobile;

  RegisterParkingPage({
    required this.name,
    required this.email,
    required this.password,
    required this.mobile,
  });

  @override
  _RegisterParkingPageState createState() => _RegisterParkingPageState();
}

class _RegisterParkingPageState extends State<RegisterParkingPage> {
  final TextEditingController parkingNameController = TextEditingController();
  final TextEditingController areaController = TextEditingController();
  final TextEditingController bikeCostController = TextEditingController();
  final TextEditingController carCostController = TextEditingController();
  final TextEditingController gmapLinkController = TextEditingController();
  final TextEditingController bikeSlotsController = TextEditingController();
  final TextEditingController carSlotsController = TextEditingController();

  void _validateAndProceed() {
    String parkingName = parkingNameController.text.trim();
    String area = areaController.text.trim();
    String bikeCost = bikeCostController.text.trim();
    String carCost = carCostController.text.trim();
    String gmapLink = gmapLinkController.text.trim();
    String bikeSlots = bikeSlotsController.text.trim();
    String carSlots = carSlotsController.text.trim();

    if (parkingName.isEmpty || area.isEmpty || bikeCost.isEmpty || carCost.isEmpty || gmapLink.isEmpty || bikeSlots.isEmpty || carSlots.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("All fields are required!")),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RegisterParking2(
          name: widget.name,
          email: widget.email,
          password: widget.password,
          mobile: widget.mobile,
          parkingName: parkingName,
          area: area, // Passing the new "Area" field
          bikeSlots: bikeSlots,
          carSlots: carSlots,
          bikeCost: bikeCost,
          carCost: carCost,
          gmapLink: gmapLink,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      resizeToAvoidBottomInset: true, // Prevent overflow
      appBar: AppBar(
        backgroundColor: Colors.purple,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text("Register Parking", style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildTextField(parkingNameController, "Parking Name"),
            _buildTextField(areaController, "Area"), // New Area Field
            _buildTextField(bikeSlotsController, "Number of Slots for Bike", keyboardType: TextInputType.number),
            _buildTextField(carSlotsController, "Number of Slots for Car", keyboardType: TextInputType.number),
            _buildTextField(bikeCostController, "Cost per Hour for Bike", keyboardType: TextInputType.number),
            _buildTextField(carCostController, "Cost per Hour for Car", keyboardType: TextInputType.number),
            _buildTextField(gmapLinkController, "Google Maps Link"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _validateAndProceed,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                minimumSize: Size(double.infinity, 50),
              ),
              child: Text("NEXT", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, {TextInputType keyboardType = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          hintText: hint,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }
}
