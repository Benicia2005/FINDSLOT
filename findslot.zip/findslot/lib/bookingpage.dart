import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';

import 'common.dart';

class BookingPage extends StatefulWidget {
  @override
  State<BookingPage> createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  String selectedVehicle = "Bike";
  Map<String, dynamic>? landData;
  bool isLoading = true;
  String? qrCodePath;
  int? bookingId;

  @override
  void initState() {
    super.initState();
    fetchLandDetails();
  }

  Future<void> fetchLandDetails() async {
    final response = await http.post(
      Uri.parse(ip + "landdetails.php"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": land}),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          landData = data['land'];
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    }
  }

  Future<void> bookSlot() async {
    try {
      final response = await http.post(
        Uri.parse(ip + "slot_booking.php"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "vehicle_type": selectedVehicle.toLowerCase(),
          "user": id, // Assuming 'user' is defined in common.dart
          "land": land // Assuming 'land' is defined in common.dart
        }),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            bookingId = data['booking_id'];
            qrCodePath = data['qr_code_path'];
          });
          showBookingSuccess(data['booking_id'], data['qr_code_path']);
        } else {
          showAlert("Booking failed: ${data['message']}");
        }
      } else {
        showAlert("Server error. Please try again later.");
      }
    } catch (e) {
      showAlert("Error: ${e.toString()}");
    }
  }

  void openMap() {
    if (landData != null && landData!["map_link"] != null) {
      final Uri url = Uri.parse(landData!["map_link"]);

      final intent = AndroidIntent(
        action: 'android.intent.action.VIEW',
        data: url.toString(),
        flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
      );

      intent.launch();
    } else {
      print("Invalid or null map link");
    }
  }

  void showAlert(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Alert"),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("OK"),
            ),
          ],
        );
      },
    );
  }

  void showBookingSuccess(int bookingId, String qrCodePath) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Booking Successful"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Booking ID: $bookingId"),
              const SizedBox(height: 10),
              Image.network(
                ip + qrCodePath,
                height: 200,
                width: 200,
                fit: BoxFit.contain,
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return Center(
                    child: CircularProgressIndicator(
                      value: loadingProgress.expectedTotalBytes != null
                          ? loadingProgress.cumulativeBytesLoaded /
                          loadingProgress.expectedTotalBytes!
                          : null,
                    ),
                  );
                },
              ),
              const SizedBox(height: 10),

            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("OK"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text("BOOKING",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : landData == null
          ? const Center(
          child: Text("No Data Found", style: TextStyle(color: Colors.white)))
          : Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.network(
            ip + landData!["image"],
            width: double.infinity,
            height: 250,
            fit: BoxFit.cover,
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  landData!["slotname"],
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
                const SizedBox(width: 5),
                GestureDetector(
                  onTap: openMap,
                  child: Image.asset(
                    'assets/mp.png',
                    height: 40,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10)),
            child: Column(
              children: [
                const Text("SLOT INFORMATION",
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      children: [
                        const Icon(Icons.motorcycle, size: 30),
                        const SizedBox(height: 5),
                        Text(landData!["no_of_bike_slot_available"]
                            .toString()),
                      ],
                    ),
                    Column(
                      children: const [
                        Text("SLOTS AVAILABLE",
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold)),
                        SizedBox(height: 5),
                        Text("COST",
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                    Column(
                      children: [
                        const Icon(Icons.directions_car, size: 30),
                        const SizedBox(height: 5),
                        Text(landData!["no_of_car_slot_available"]
                            .toString()),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("₹${landData!["bike_cost"]}/hr"),
                    Text("₹${landData!["car_cost"]}/hr"),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 50),
          const Text("SELECT VEHICLE TYPE",
              style: TextStyle(color: Colors.white)),
          const SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildSelectableButton("Bike"),
              const SizedBox(width: 10),
              _buildSelectableButton("Car"),
            ],
          ),
          const SizedBox(height: 60),
          ElevatedButton(
            onPressed: () {
              if ((selectedVehicle == "Bike" &&
                  landData!["no_of_bike_slot_available"] == 0) ||
                  (selectedVehicle == "Car" &&
                      landData!["no_of_car_slot_available"] == 0)) {
                showAlert("Cannot book, slots are full");
              } else {
                bookSlot();
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple),
            child: const Text("BOOK NOW",
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectableButton(String vehicleType) {
    return GestureDetector(
      onTap: () => setState(() => selectedVehicle = vehicleType),
      child: Container(
        width: 150,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
        decoration: BoxDecoration(
          color: selectedVehicle == vehicleType ? Colors.purple : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.purple),
        ),
        child: Text(
          vehicleType,
          style: TextStyle(
              color: selectedVehicle == vehicleType ? Colors.white : Colors.purple),
        ),
      ),
    );
  }
}