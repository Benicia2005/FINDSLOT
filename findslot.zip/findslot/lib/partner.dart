import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:findslot/partnereditpage.dart';
import 'package:findslot/partnerlogin.dart';
import 'package:findslot/scanpage.dart';
import 'package:findslot/scanpage1.dart';
import 'package:findslot/secondpage.dart';

import 'common.dart';
import 'editpartner.dart';

class Partner extends StatefulWidget {
  @override
  _PartnerState createState() => _PartnerState();
}

class _PartnerState extends State<Partner> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    PartnerHome(),
    PartnerHistory(),
    PartnerProfile(), // Request Page (To be implemented)
     // History Page (To be implemented)
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Partner"),
        backgroundColor: Colors.purple,
        centerTitle: true,
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        backgroundColor: Colors.white,
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.grey,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: "History",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profile",
          ),
        ],
      ),
    );
  }
}

class PartnerHome extends StatefulWidget {
  @override
  _PartnerHomeState createState() => _PartnerHomeState();
}

class _PartnerHomeState extends State<PartnerHome> {
  int bookedSlots = 0;
  int availableSlots = 0;
  String email = id; // Replace with the logged-in user's email

  @override
  void initState() {
    super.initState();
    fetchSlotData();
  }

  Future<void> fetchSlotData() async {
    final url = Uri.parse(ip+"partnerhome.php"); // Replace with your API URL
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": email}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      print(data.toString());
      if (data["status"] == "success") {
        print(data.toString());
        setState(() {
          bookedSlots = data["total_slots_booked"];
          availableSlots = data["total_slots_available"];
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 50),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildStatCard("Number of slots booked", bookedSlots.toString(), Colors.red),
              _buildStatCard("Number of slots vacant", availableSlots.toString(), Colors.green),
            ],
          ),
          SizedBox(height: 20),
          Image.asset(
            "assets/pthm.png",
            height: 350,
            fit: BoxFit.contain,
          ),
          SizedBox(height: 30),
          _buildButton(context, "IN"),
          SizedBox(height: 10),
          _buildButton(context, "OUT"),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String count, Color color) {
    return Container(
      width: 150,
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white, fontSize: 14),
          ),
          SizedBox(height: 8),
          Text(
            count,
            style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildButton(context, String text) {
    return ElevatedButton(
      onPressed: () {
        if(text=="IN"){
          Navigator.push(context, MaterialPageRoute(builder: (context) => QRScannerPageIN()));
        }
        else{
          Navigator.push(context, MaterialPageRoute(builder: (context) => QRScannerPageOUT()));
        }

      },
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.purple,
        minimumSize: Size(200, 50),
      ),
      child: Text(
        text,
        style: TextStyle(fontSize: 18, color: Colors.white),
      ),
    );
  }
}

class PartnerProfile extends StatefulWidget {
  @override
  _PartnerProfileState createState() => _PartnerProfileState();
}

class _PartnerProfileState extends State<PartnerProfile> {
  Map<String, dynamic>? landDetails;
  bool isLoading = true;
  final String email = "priya@gmail.com";

  @override
  void initState() {
    super.initState();
    fetchLandDetails();
  }

  Future<void> fetchLandDetails() async {
    final response = await http.post(
      Uri.parse(ip+"partnerprofile.php"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": id}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data["status"] == "success") {
        setState(() {
          landDetails = data["land_details"];
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  void _logout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Logout"),
        content: Text("Are you sure you want to logout?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => UserPage())); // Handle logout logic
            },
            child: Text("Logout", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Partner Profile"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout, color: Colors.white),
            onPressed: _logout,
          )
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : landDetails == null
          ? Center(
        child: Text(
          "No land details found",
          style: TextStyle(color: Colors.white),
        ),
      )
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 50,
                backgroundColor: Colors.white,
                child: Icon(Icons.person, size: 60, color: Colors.purple),
              ),
              SizedBox(height: 10),
              Text(
                "Your Information",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              ListView(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                children: [
                  _buildDetailField("Slot Name", landDetails!["slotname"] ?? "N/A"),
                  _buildDetailField("Area", landDetails!["area"] ?? "N/A"),
                  _buildDetailField("Bike Slots", landDetails!["no_of_slots_for_bike"].toString() ?? "N/A"),
                  _buildDetailField("Car Slots", landDetails!["no_of_slots_for_car"].toString() ?? "N/A"),
                  _buildDetailField("Bike Cost", "₹${landDetails!["bike_cost"].toString()}"),
                  _buildDetailField("Car Cost", "₹${landDetails!["car_cost"].toString()}"),
                  _buildDetailField("Map Link", landDetails!["map_link"] ?? "N/A", isLink: true),
                ],
              ),
              SizedBox(height: 40),
              ElevatedButton(
                onPressed:  () async {
              final updatedDetails = await Navigator.push(
              context,
              MaterialPageRoute(
              builder: (context) => EditPartnerPage(landDetails: landDetails!),
              ),
              );

              if (updatedDetails != null) {
              setState(() {
              landDetails = updatedDetails;
              });
              }
              },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  minimumSize: Size(double.infinity, 50),
                ),
                child: Text(
                  "EDIT PROFILE",
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _buildDetailField(String label, String value, {bool isLink = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: Colors.white70, fontSize: 14)),
          SizedBox(height: 5),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
            child: isLink
                ? GestureDetector(
              onTap: () {}, // Handle opening the link
              child: Text(value, style: TextStyle(color: Colors.blue, decoration: TextDecoration.underline)),
            )
                : Text(value, style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
    );
  }
}

class PartnerHistory extends StatefulWidget {
   // Pass email from login



  @override
  _PartnerHistoryState createState() => _PartnerHistoryState();
}

class _PartnerHistoryState extends State<PartnerHistory> {
  int _selectedTabIndex = 0; // 0 -> Pending, 1 -> In, 2 -> Out
  List<Map<String, dynamic>> pending = [];
  List<Map<String, dynamic>> inList = [];
  List<Map<String, dynamic>> outList = [];
  bool isLoading = true;
  String errorMessage = "";

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    setState(() {
      isLoading = true;
      errorMessage = "";
    });

    try {
      final response = await http.post(
        Uri.parse(ip+"partnerhistory.php"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"email": id}),
      );

      final data = jsonDecode(response.body);
      if (data["status"] == "success") {
        setState(() {
          pending = List<Map<String, dynamic>>.from(data["pending"]);
          inList = List<Map<String, dynamic>>.from(data["in"]);
          outList = List<Map<String, dynamic>>.from(data["out"]);
          isLoading = false;
        });
      } else {
        setState(() {
          errorMessage = data["message"];
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Failed to load data. Please try again.";
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> displayList;
    switch (_selectedTabIndex) {
      case 0:
        displayList = pending;
        break;
      case 1:
        displayList = inList;
        break;
      case 2:
        displayList = outList;
        break;
      default:
        displayList = [];
    }

    return Scaffold(
      backgroundColor: Colors.black,

      body: Column(
        children: [
          _buildTabBar(),
          isLoading
              ? Center(child: CircularProgressIndicator())
              : errorMessage.isNotEmpty
              ? Center(child: Text(errorMessage, style: TextStyle(color: Colors.white)))
              : Expanded(
            child: displayList.isEmpty
                ? Center(child: Text("No data available", style: TextStyle(color: Colors.white)))
                : ListView.builder(
              padding: EdgeInsets.all(16.0),
              itemCount: displayList.length,
              itemBuilder: (context, index) {
                return _buildHistoryCard(displayList[index]);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: Colors.purple,
      child: Row(
        children: [
          _buildTabButton("Pending", 0),
          _buildTabButton("In", 1),
          _buildTabButton("Out", 2),
        ],
      ),
    );
  }

  Widget _buildTabButton(String label, int index) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _selectedTabIndex = index;
          });
        },
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: _selectedTabIndex == index ? Colors.white : Colors.transparent,
                width: 2,
              ),
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> historyItem) {
    return Card(
      color: Colors.white,
      margin: EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: Colors.grey,
                  child: Icon(Icons.person, color: Colors.white),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    historyItem["user"] ?? "Unknown User",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
                Text(
                  historyItem["vehicle_type"] ?? "Unknown",
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.purple),
                ),
              ],
            ),
            SizedBox(height: 5),
            if (historyItem.containsKey("in_time")) Text("In Time: ${historyItem["in_time"]}"),
            if (historyItem.containsKey("out_time")) Text("Out Time: ${historyItem["out_time"]}"),
            if (historyItem.containsKey("cost")) Text("Cost: ₹${historyItem["cost"]}"),
            SizedBox(height: 5),
            Text(
              _selectedTabIndex == 0 ? "Pending" : (_selectedTabIndex == 1 ? "Checked In" : "Checked Out"),
              style: TextStyle(
                color: _selectedTabIndex == 1 ? Colors.green : (_selectedTabIndex == 2 ? Colors.red : Colors.orange),
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
