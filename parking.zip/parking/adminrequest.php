<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish the database connection
    require("conn.php");

    // Check connection
    if ($con->connect_error) {
        die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
    }

    // Query to fetch land details
    $sql = "SELECT slotname, area, email, image FROM land where status = 'pending'";
    $result = $con->query($sql);

    // Prepare response
    if ($result->num_rows > 0) {
        $lands = [];
        while ($row = $result->fetch_assoc()) {
            $lands[] = $row;
        }
        $response = ["status" => "success", "lands" => $lands];
    } else {
        $response = ["status" => "failure", "message" => "No lands found"];
    }

    // Close the database connection
    $con->close();

    // Return response as JSON
    echo json_encode($response);
}
?>

