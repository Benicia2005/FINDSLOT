<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"])) {
        $email = $data["email"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // SQL query to fetch land details along with available bike and car slots
        $sql = "
            SELECT 
                l.slotname, 
                l.area, 
                (l.no_of_slots_for_bike - (
                    SELECT COUNT(*) FROM booking 
                    WHERE booking.land = l.email 
                    AND booking.in_time IS NOT NULL 
                    AND booking.out_time IS NULL 
                    AND booking.vehicle_type = 'bike'
                )) AS no_of_bike_slot_available,
                (l.no_of_slots_for_car - (
                    SELECT COUNT(*) FROM booking 
                    WHERE booking.land = l.email 
                    AND booking.in_time IS NOT NULL 
                    AND booking.out_time IS NULL 
                    AND booking.vehicle_type = 'car'
                )) AS no_of_car_slot_available,
                l.bike_cost, 
                l.car_cost,
                l.image, 
                l.map_link
            FROM land l
            WHERE l.email = ?
        ";

        $stmt = $con->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        if ($result->num_rows > 0) {
            $land = $result->fetch_assoc();
            $response = [
                "status" => "success",
                "land" => $land
            ];
        } else {
            $response = [
                "status" => "failure",
                "message" => "No land found for the given email"
            ];
        }

        // Close the database connection
        $con->close();
    } else {
        $response = [
            "status" => "failure",
            "message" => "Email not provided"
        ];
    }

    echo json_encode($response);
}
?>
