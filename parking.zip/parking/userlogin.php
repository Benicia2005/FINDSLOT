<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"]) && isset($data["password"])) {
        $email = $data["email"];
        $password = $data["password"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // Prepare SQL statement to prevent SQL injection
        $stmt = $con->prepare("SELECT * FROM usersignup WHERE email = ? AND password = ?");
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Fetch the user details
            $row = $result->fetch_assoc();

            // Login successful
            $response = [
                "status" => "success",
                "message" => "Login successful",
            ];
        } else {
            // Login failed
            $response = [
                "status" => "failure",
                "message" => "Invalid email or password"
            ];
        }

        // Close the statement and connection
        $stmt->close();
        $con->close();

    } else {
        $response = [
            "status" => "failure",
            "message" => "Email or password not provided"
        ];
    }

    echo json_encode($response);
}
?>
