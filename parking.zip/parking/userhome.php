<?php

// Establish the database connection
require("conn.php");

// Check connection
if ($con->connect_error) {
    die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
}

// SQL query to fetch land details along with available bike and car slots
$sql = "
    SELECT 
        l.email, 
        l.slotname, 
        l.area, 
        (l.no_of_slots_for_bike - (
            SELECT COUNT(*) FROM booking 
            WHERE booking.land = l.email 
            AND booking.in_time IS NOT NULL 
            AND booking.out_time IS NULL 
            AND booking.vehicle_type = 'bike'
        )) AS no_of_bike_slot_available,
        (l.no_of_slots_for_car - (
            SELECT COUNT(*) FROM booking 
            WHERE booking.land = l.email 
            AND booking.in_time IS NOT NULL 
            AND booking.out_time IS NULL 
            AND booking.vehicle_type = 'car'
        )) AS no_of_car_slot_available,
        l.bike_cost, 
        l.car_cost,
        l.image
    FROM land l
";

$result = $con->query($sql);

if ($result->num_rows > 0) {
    $lands = $result->fetch_all(MYSQLI_ASSOC);
    $response = [
        "status" => "success",
        "lands" => $lands
    ];
} else {
    $response = [
        "status" => "failure",
        "message" => "No lands found"
    ];
}

// Close the database connection
$con->close();

echo json_encode($response);

?>
