<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"]) && isset($data["password"]) && isset($data["mobilenumber"]) && isset($data["name"])) {
        $email = $data["email"];
        $password = $data["password"];
        $mobilenumber = $data["mobilenumber"];
        $name = $data["name"];

        // Establish the database connection
        require("conn.php");

        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // Check if email already exists
        $stmt = $con->prepare("SELECT email FROM usersignup WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Email already exists
            $response = [
                "status" => "failure",
                "message" => "Email already registered"
            ];
        } else {
            // Insert new user
            $stmt = $con->prepare("INSERT INTO usersignup (email, password, mobilenumber, name) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $email, $password, $mobilenumber, $name);

            if ($stmt->execute()) {
                $response = [
                    "status" => "success",
                    "message" => "User registered successfully"
                ];
            } else {
                $response = [
                    "status" => "failure",
                    "message" => "Error in registration"
                ];
            }
            $stmt->close();
        }

        // Close connection
        $con->close();
    } else {
        $response = [
            "status" => "failure",
            "message" => "All fields are required"
        ];
    }

    echo json_encode($response);
}
?>
