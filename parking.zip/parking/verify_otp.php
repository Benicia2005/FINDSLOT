<?php
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status'=>'failure','message'=>'Invalid request']);
  exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$email = $data['email'] ?? '';
$otp   = $data['otp']   ?? '';

if (empty($email) || empty($otp)) {
  echo json_encode(['status'=>'failure','message'=>'Email and OTP required']);
  exit;
}

require 'conn.php';
if ($con->connect_error) {
  echo json_encode(['status'=>'failure','message'=>'DB connection error']);
  exit;
}

$stmt = $con->prepare("SELECT otp_code FROM usersignup WHERE email = ? AND otp_code = ?");
$stmt->bind_param("si", $email, $otp);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
  echo json_encode(['status'=>'failure','message'=>'Invalid OTP']);
} else {
  // clear OTP
  $clear = $con->prepare("UPDATE usersignup SET otp_code = NULL WHERE email = ?");
  $clear->bind_param("s", $email);
  $clear->execute();
  $clear->close();

  echo json_encode(['status'=>'success','message'=>'OTP verified']);
}
$stmt->close();
$con->close();
