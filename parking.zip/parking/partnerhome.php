<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"])) {
        $email = $data["email"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // Query to get total slots booked
        $sqlBooked = "SELECT COUNT(*) AS total_booked FROM booking WHERE land = ? AND in_time IS NOT NULL AND out_time IS NULL";
        $stmtBooked = $con->prepare($sqlBooked);
        $stmtBooked->bind_param("s", $email);
        $stmtBooked->execute();
        $resultBooked = $stmtBooked->get_result();
        $rowBooked = $resultBooked->fetch_assoc();
        $totalBooked = $rowBooked["total_booked"];
        $stmtBooked->close();

        // Query to get total slots available
        $sqlLand = "SELECT no_of_slots_for_bike, no_of_slots_for_car FROM land WHERE email = ?";
        $stmtLand = $con->prepare($sqlLand);
        $stmtLand->bind_param("s", $email);
        $stmtLand->execute();
        $resultLand = $stmtLand->get_result();
        $stmtLand->close();

        if ($resultLand->num_rows > 0) {
            $rowLand = $resultLand->fetch_assoc();
            $totalSlots = $rowLand["no_of_slots_for_bike"] + $rowLand["no_of_slots_for_car"];
            $totalAvailable = $totalSlots - $totalBooked;

            $response = [
                "status" => "success",
                "total_slots_booked" => $totalBooked,
                "total_slots_available" => $totalAvailable
            ];
        } else {
            $response = [
                "status" => "failure",
                "message" => "Land details not found for the given email"
            ];
        }

        // Close the database connection
        $con->close();
    } else {
        $response = ["status" => "failure", "message" => "Email not provided"];
    }

    echo json_encode($response);
}
?>
