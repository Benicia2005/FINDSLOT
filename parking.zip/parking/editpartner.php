<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"])) {
        $email = $data["email"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // Fetch existing data
        $sql = "SELECT * FROM land WHERE email = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        if ($result->num_rows == 0) {
            echo json_encode(["status" => "failure", "message" => "No land details found for the given email"]);
            $con->close();
            exit();
        }

        // Update query with dynamic fields
        $updates = [];
        $params = [];
        $param_types = "";

        if (isset($data["slotname"])) {
            $updates[] = "slotname = ?";
            $params[] = $data["slotname"];
            $param_types .= "s";
        }
        if (isset($data["area"])) {
            $updates[] = "area = ?";
            $params[] = $data["area"];
            $param_types .= "s";
        }
        if (isset($data["no_of_slots_for_bike"])) {
            $updates[] = "no_of_slots_for_bike = ?";
            $params[] = $data["no_of_slots_for_bike"];
            $param_types .= "i";
        }
        if (isset($data["no_of_slots_for_car"])) {
            $updates[] = "no_of_slots_for_car = ?";
            $params[] = $data["no_of_slots_for_car"];
            $param_types .= "i";
        }
        if (isset($data["bike_cost"])) {
            $updates[] = "bike_cost = ?";
            $params[] = $data["bike_cost"];
            $param_types .= "d";
        }
        if (isset($data["car_cost"])) {
            $updates[] = "car_cost = ?";
            $params[] = $data["car_cost"];
            $param_types .= "d";
        }
        if (isset($data["map_link"])) {
            $updates[] = "map_link = ?";
            $params[] = $data["map_link"];
            $param_types .= "s";
        }

        if (!empty($updates)) {
            $sql = "UPDATE land SET " . implode(", ", $updates) . " WHERE email = ?";
            $params[] = $email;
            $param_types .= "s";

            $stmt = $con->prepare($sql);
            $stmt->bind_param($param_types, ...$params);
            if ($stmt->execute()) {
                $response = ["status" => "success", "message" => "Land details updated successfully"];
            } else {
                $response = ["status" => "failure", "message" => "Failed to update land details"];
            }
            $stmt->close();
        } else {
            $response = ["status" => "failure", "message" => "No valid fields provided for update"];
        }

        // Close the database connection
        $con->close();
    } else {
        $response = ["status" => "failure", "message" => "Email not provided"];
    }

    echo json_encode($response);
}
?>
