<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get posted data
    $email = $_POST["email"] ?? '';
    $reason = $_POST["reason"] ?? '';
    $status = $_POST["status"] ?? '';

    // Validate input
    if (empty($email) || empty($status)) {
        echo json_encode(["status" => "failure", "message" => "Email and status are required"]);
        exit();
    }

    // Establish database connection
    require("conn.php");

    // Check connection
    if ($con->connect_error) {
        die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
    }

    // Update query
    $sql = "UPDATE land SET reason = ?, status = ? WHERE email = ?";
    
    // Prepare statement
    $stmt = $con->prepare($sql);
    $stmt->bind_param("sss", $reason, $status, $email);

    // Execute query
    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Land status updated successfully"]);
    } else {
        echo json_encode(["status" => "failure", "message" => "Failed to update land status"]);
    }

    // Close resources
    $stmt->close();
    $con->close();
}
?>
