<?php
require 'conn.php'; // Ensure your database connection file is correct

date_default_timezone_set('Asia/Kolkata');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["id"])) {
        $id = $data["id"];
        $in_time = date("Y-m-d H:i:s"); // Get current date-time

        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        $stmt = $con->prepare("UPDATE booking SET in_time = ? WHERE id = ?");
        $stmt->bind_param("si", $in_time, $id);

        if ($stmt->execute()) {
            $response = ["status" => "success", "message" => "Booking updated successfully"];
        } else {
            $response = ["status" => "failure", "message" => "Error updating booking"];
        }

        $stmt->close();
        $con->close();
    } else {
        $response = ["status" => "failure", "message" => "Booking ID is required"];
    }

    echo json_encode($response);
}
?>
