<?php
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status'=>'failure','message'=>'Invalid request method']);
  exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (empty($data['email'])) {
  echo json_encode(['status'=>'failure','message'=>'Email is required']);
  exit;
}
$email = trim($data['email']);

require 'conn.php';
if ($con->connect_error) {
  echo json_encode(['status'=>'failure','message'=>'DB connection failed']);
  exit;
}

// 1) Check user exists
$stmt = $con->prepare("SELECT id FROM usersignup WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
  echo json_encode(['status'=>'failure','message'=>'No account with that email']);
  $stmt->close(); $con->close(); exit;
}
$stmt->close();

// 2) Generate & store OTP
$otp = rand(1000, 9999);
$upd = $con->prepare("UPDATE usersignup SET otp_code = ? WHERE email = ?");
$upd->bind_param("is", $otp, $email);
if (!$upd->execute()) {
  echo json_encode(['status'=>'failure','message'=>'Could not save OTP']);
  $upd->close(); $con->close(); exit;
}
$upd->close();

// 3) Send OTP via email
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require __DIR__.'/PHPMailer/src/Exception.php';
require __DIR__.'/PHPMailer/src/PHPMailer.php';
require __DIR__.'/PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);
try {
  $mail->isSMTP();
  $mail->Host       = 'smtp.gmail.com';
  $mail->SMTPAuth   = true;
  $mail->Username   = 'akmgamers54@gmail.com';
  $mail->Password   = 'xrtw zwzf cqgo eref';
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port       = 587;

  $mail->setFrom('akmgamers54@gmail.com','FindSlot');
  $mail->addAddress($email);
  $mail->Subject = 'Your Password Reset OTP';
  $mail->Body    = "Your OTP is: $otp\n\nIf you didn’t request this, ignore.";

  $mail->send();
  echo json_encode(['status'=>'success','message'=>'OTP sent to your email']);
} catch (Exception $e) {
  echo json_encode(['status'=>'failure','message'=>'Mailer Error: '.$mail->ErrorInfo]);
}

$con->close();
