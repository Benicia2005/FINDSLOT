<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the posted email
    $email = $_POST["email"] ?? '';

    if (empty($email)) {
        echo json_encode(["status" => "failure", "message" => "Email is required"]);
        exit();
    }

    // Establish the database connection
    require("conn.php");

    // Check connection
    if ($con->connect_error) {
        die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
    }

    // Query to fetch land details based on email
    $sql = "SELECT slotname, area, no_of_slots_for_bike, no_of_slots_for_car, bike_cost, car_cost, map_link, proof, image 
            FROM land 
            WHERE email = ?";
    
    // Prepare and execute the query
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Prepare response
    if ($result->num_rows > 0) {
        $land = $result->fetch_assoc();
        $response = ["status" => "success", "land_details" => $land];
    } else {
        $response = ["status" => "failure", "message" => "No land found for this email"];
    }

    // Close resources
    $stmt->close();
    $con->close();

    // Return response as JSON
    echo json_encode($response);
}
?>
