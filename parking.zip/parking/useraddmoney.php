<?php
include 'conn.php'; // your database connection

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status'  => 'failure',
        'message' => 'Only POST requests are allowed'
    ]);
    exit;
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (empty($data['email']) || !isset($data['amount'])) {
    echo json_encode([
        'status'  => 'failure',
        'message' => 'Email and amount are required'
    ]);
    exit;
}

$email  = $data['email'];
$amount = $data['amount'];

if (!is_numeric($amount) || $amount <= 0) {
    echo json_encode([
        'status'  => 'failure',
        'message' => 'Invalid amount'
    ]);
    exit;
}

// 1) Fetch current balance
if ($stmt = $con->prepare("SELECT balance FROM usersignup WHERE email = ?")) {
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($currentBalance);

    if (!$stmt->fetch()) {
        echo json_encode([
            'status'  => 'failure',
            'message' => 'User not found'
        ]);
        $stmt->close();
        $con->close();
        exit;
    }
    $stmt->close();
} else {
    echo json_encode([
        'status'  => 'failure',
        'message' => 'Database error (fetch)'
    ]);
    $con->close();
    exit;
}

// 2) Update to new balance
$newBalance = $currentBalance + (int)$amount;
if ($upd = $con->prepare("UPDATE usersignup SET balance = ? WHERE email = ?")) {
    $upd->bind_param("is", $newBalance, $email);
    if ($upd->execute()) {
        echo json_encode([
            'status'  => 'success',
            'balance' => $newBalance
        ]);
    } else {
        echo json_encode([
            'status'  => 'failure',
            'message' => 'Failed to update balance'
        ]);
    }
    $upd->close();
} else {
    echo json_encode([
        'status'  => 'failure',
        'message' => 'Database error (update)'
    ]);
}

$con->close();