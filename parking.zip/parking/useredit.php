<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"], $data["name"], $data["mobilenumber"])) {
        $email = $data["email"];
        $name = $data["name"];
        $mobilenumber = $data["mobilenumber"];

        // Establish the database connection
        require("conn.php");

        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // SQL query to update user details
        $sql = "UPDATE usersignup SET name = ?, mobilenumber = ? WHERE email = ?";

        $stmt = $con->prepare($sql);
        $stmt->bind_param("sss", $name, $mobilenumber, $email);

        if ($stmt->execute()) {
            $response = ["status" => "success", "message" => "Profile updated successfully"];
        } else {
            $response = ["status" => "failure", "message" => "Failed to update profile"];
        }

        $stmt->close();
        $con->close();
    } else {
        $response = ["status" => "failure", "message" => "Invalid input"];
    }

    echo json_encode($response);
}
?>
