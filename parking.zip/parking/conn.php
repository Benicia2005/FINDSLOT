<?php
$con=mysqli_connect("localhost","root","","parkingspacefinder");
if($con->connect_error){
    die("Connection failed ".$conn->connect_error);
}
?>