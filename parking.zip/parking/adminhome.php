<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish the database connection
    require("conn.php");

    // Check connection
    if ($con->connect_error) {
        die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
    }

    // Query to get total number of users
    $sqlUsers = "SELECT COUNT(*) AS total_users FROM usersignup";
    $resultUsers = $con->query($sqlUsers);
    $rowUsers = $resultUsers->fetch_assoc();
    $totalUsers = $rowUsers["total_users"];

    // Query to get total number of approved parking spaces
    $sqlApproved = "SELECT COUNT(*) AS total_parking FROM land WHERE status = 'approved'";
    $resultApproved = $con->query($sqlApproved);
    $rowApproved = $resultApproved->fetch_assoc();
    $totalParking = $rowApproved["total_parking"];

    // Query to get total number of pending parking spaces
    $sqlPending = "SELECT COUNT(*) AS total_pending FROM land WHERE status = 'pending'";
    $resultPending = $con->query($sqlPending);
    $rowPending = $resultPending->fetch_assoc();
    $totalPending = $rowPending["total_pending"];

    // Prepare response
    $response = [
        "status" => "success",
        "total_no_of_users" => $totalUsers,
        "total_no_of_parking" => $totalParking,
        "total_no_of_pending" => $totalPending
    ];

    // Close the database connection
    $con->close();

    // Return response as JSON
    echo json_encode($response);
}
?>
