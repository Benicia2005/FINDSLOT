<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"])) {
        $email = $data["email"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // SQL query to fetch user details
        $sql = "SELECT name, email, mobilenumber FROM usersignup WHERE email = ?";

        $stmt = $con->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $response = [
                "status" => "success",
                "user" => $user
            ];
        } else {
            $response = [
                "status" => "failure",
                "message" => "No user found for the given email"
            ];
        }

        // Close the database connection
        $con->close();
    } else {
        $response = [
            "status" => "failure",
            "message" => "Email not provided"
        ];
    }

    echo json_encode($response);
}
?>
