<?php
require 'conn.php'; // Ensure your database connection file is correct

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"])) {
        $email = $data["email"];

        // Fetch balance from usersignup table
        $stmt = $con->prepare("SELECT balance FROM usersignup WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($balance);

        if ($stmt->fetch()) {
            $response = ["status" => "success", "balance" => $balance];
        } else {
            $response = ["status" => "failure", "message" => "Email not found"];
        }

        $stmt->close();
        $con->close();
    } else {
        $response = ["status" => "failure", "message" => "Email is required"];
    }

    echo json_encode($response);
}
?>
