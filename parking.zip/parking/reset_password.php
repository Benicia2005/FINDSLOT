<?php
header('Content-Type: application/json');

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['status' => 'failure', 'message' => 'Invalid request']);
  exit;
}

// Parse JSON payload
$data     = json_decode(file_get_contents('php://input'), true);
$email    = $data['email']    ?? '';
$password = $data['password'] ?? '';

if (empty($email) || empty($password)) {
  echo json_encode(['status' => 'failure', 'message' => 'Email and new password required']);
  exit;
}

require 'conn.php';  // conn.php should initialize $con = new mysqli(...)
if ($con->connect_error) {
  echo json_encode(['status' => 'failure', 'message' => 'DB connection error']);
  exit;
}

// Update without hashing
$stmt = $con->prepare("
  UPDATE usersignup
     SET password = ?,
         otp_code  = NULL
   WHERE email    = ?
");
$stmt->bind_param("ss", $password, $email);

if ($stmt->execute()) {
  echo json_encode(['status' => 'success', 'message' => 'Password reset successful']);
} else {
  echo json_encode(['status' => 'failure', 'message' => 'Could not update password']);
}

$stmt->close();
$con->close();
