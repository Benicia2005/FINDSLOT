<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"])) {
        $email = $data["email"];

        // Establish the database connection
        require("conn.php");

        // Check connection
        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // Fetch Pending (where in_time and out_time = NULL)
        $stmt = $con->prepare("SELECT user, vehicle_type FROM booking WHERE land = ? AND in_time IS NULL AND out_time IS NULL");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $pending_result = $stmt->get_result();
        $pending = $pending_result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // Fetch In (where in_time != NULL and out_time = NULL)
        $stmt = $con->prepare("SELECT user, in_time, vehicle_type FROM booking WHERE land = ? AND in_time IS NOT NULL AND out_time IS NULL");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $in_result = $stmt->get_result();
        $in = $in_result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // Fetch Out (where in_time != NULL and out_time != NULL)
        $stmt = $con->prepare("SELECT user, in_time, out_time, vehicle_type,cost FROM booking WHERE land = ? AND in_time IS NOT NULL AND out_time IS NOT NULL");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $out_result = $stmt->get_result();
        $out = $out_result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // Close the database connection
        $con->close();

        // Prepare response
        $response = [
            "status" => "success",
            "pending" => $pending,
            "in" => $in,
            "out" => $out
        ];
    } else {
        $response = [
            "status" => "failure",
            "message" => "Email not provided"
        ];
    }

    echo json_encode($response);
}
?>
