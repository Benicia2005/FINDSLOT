<?php
require 'conn.php';
require 'phpqrcode/qrlib.php'; // Ensure you have this library installed

date_default_timezone_set('Asia/Kolkata');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["vehicle_type"]) && isset($data["user"]) && isset($data["land"])) {
        $vehicle_type = $data["vehicle_type"];
        $user = $data["user"];
        $land = $data["land"];
        
        

        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        $stmt = $con->prepare("INSERT INTO booking (vehicle_type, user, land) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $vehicle_type, $user, $land);

        if ($stmt->execute()) {
            $booking_id = $stmt->insert_id;
            $qrData = "BOOKING_ID:" . $booking_id;
            $qrDir = __DIR__ . '/uploads/qr_codes/';
            
            if (!is_dir($qrDir)) {
                mkdir($qrDir, 0755, true);
            }
            
            $qrFilePath = $qrDir . "booking_" . $booking_id . ".png";
            QRcode::png($qrData, $qrFilePath, QR_ECLEVEL_L, 10);

            
            $qrRelativePath = "uploads/qr_codes/booking_" . $booking_id . ".png";
            $updateStmt = $con->prepare("UPDATE booking SET qr_code_path = ? WHERE id = ?");
            $updateStmt->bind_param("si", $qrRelativePath, $booking_id);
            $updateStmt->execute();
            
            $response = [
                "status" => "success",
                "message" => "Booking successful",
                "booking_id" => $booking_id,
                "qr_code_path" => $qrRelativePath
            ];
        } else {
            $response = ["status" => "failure", "message" => "Error in booking"];
        }

        $stmt->close();
        $con->close();
    } else {
        $response = ["status" => "failure", "message" => "All fields are required"];
    }
    
    echo json_encode($response);
}
?>
