<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (empty($data["email"])) {
        echo json_encode(["status" => "failure", "message" => "Email not provided"]);
        exit;
    }

    $email = $data["email"];
    require("conn.php"); // make sure conn.php sets up $con = new mysqli(...);

    if ($con->connect_error) {
        die(json_encode([
            "status"  => "failure",
            "message" => "Connection failed: " . $con->connect_error
        ]));
    }

    $response = [
        "status"  => "success",
        "pending" => [],
        "in"      => [],
        "out"     => []
    ];

    // Pending
    $sql = "
        SELECT
          b.id           AS booking_id,
          l.slotname     AS land,
          b.vehicle_type,
          b.qr_code_path
        FROM booking b
        JOIN land l ON b.land = l.email
        WHERE b.user = ? AND b.in_time IS NULL AND b.out_time IS NULL
    ";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $response["pending"] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Checked-in
    $sql = "
        SELECT
          b.id           AS booking_id,
          l.slotname     AS land,
          b.in_time,
          b.vehicle_type,
          b.qr_code_path
        FROM booking b
        JOIN land l ON b.land = l.email
        WHERE b.user = ? AND b.in_time IS NOT NULL AND b.out_time IS NULL
    ";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $response["in"] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    // Checked-out
    $sql = "
        SELECT
          b.id           AS booking_id,
          l.slotname     AS land,
          b.in_time,
          b.out_time,
          b.cost,
          b.vehicle_type
        FROM booking b
        JOIN land l ON b.land = l.email
        WHERE b.user = ? AND b.in_time IS NOT NULL AND b.out_time IS NOT NULL
    ";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $response["out"] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $con->close();
    header('Content-Type: application/json');
    echo json_encode($response);
}
