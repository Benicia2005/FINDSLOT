<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish the database connection
    require("conn.php");

    // Check connection
    if ($con->connect_error) {
        die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
    }

    // Query to fetch land details
    $sql = "SELECT slotname, area, email, no_of_slots_for_bike, no_of_slots_for_car, bike_cost, car_cost, image, status FROM land where status in ('approved' ,'rejected')";
    $result = $con->query($sql);

    // Prepare response
    if ($result->num_rows > 0) {
        $lands = [];
        while ($row = $result->fetch_assoc()) {
            $lands[] = $row;
        }
        $response = ["status" => "success", "lands" => $lands];
    } else {
        $response = ["status" => "failure", "message" => "No lands found"];
    }

    // Close the database connection
    $con->close();

    // Return response as JSON
    echo json_encode($response);
}
?>

