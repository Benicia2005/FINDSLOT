<?php
require 'conn.php'; // Ensure your database connection file is correct

date_default_timezone_set('Asia/Kolkata');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["id"])) {
        $id = $data["id"];
        $out_time = date("Y-m-d H:i:s"); // Get current date-time

        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // Fetch in_time, vehicle_type, land ID, and user email from booking table
        $stmt = $con->prepare("SELECT in_time, vehicle_type, land, user FROM booking WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($in_time, $vehicle_type, $land, $user);
        
        if ($stmt->fetch()) {
            $stmt->close();

            // Fetch cost details from land table
            $stmt = $con->prepare("SELECT bike_cost, car_cost, balance FROM land WHERE email = ?");
            $stmt->bind_param("i", $land);
            $stmt->execute();
            $stmt->bind_result($bike_cost, $car_cost, $land_balance);
            $stmt->fetch();
            $stmt->close();

            // Fetch user balance
            $stmt = $con->prepare("SELECT balance FROM usersignup WHERE email = ?");
            $stmt->bind_param("s", $user);
            $stmt->execute();
            $stmt->bind_result($user_balance);
            $stmt->fetch();
            $stmt->close();

            // Calculate time difference in hours (including days correctly)
            $in_time_obj = new DateTime($in_time);
            $out_time_obj = new DateTime($out_time);
            $interval = $in_time_obj->diff($out_time_obj);
            $total_hours = ($interval->days * 24) + $interval->h + ($interval->i / 60); // Convert to total hours

            

            // Determine cost based on vehicle type
            if ($vehicle_type == "bike") {
                $cost = $total_hours * $bike_cost;
            } else if ($vehicle_type == "car") {
                $cost = $total_hours * $car_cost;
            } else {
                $cost = 0;
            }

            // Debugging: Print Cost Before Rounding
            error_log("Calculated Cost Before Rounding: " . $cost);

            // Round cost to nearest 0.5
            $cost = round($cost * 2) / 2;

            // Debugging: Print Cost After Rounding
            error_log("Final Cost After Rounding: " . $cost);

            // Check if cost is valid
            if ($cost <= 0) {
                $response = ["status" => "failure", "message" => "Invalid cost calculation"];
            } else if ($cost > $user_balance) {
                $response = ["status" => "failure", "message" => "Insufficient balance"];
            } else {
                // Deduct cost from user balance and add to land balance
                $new_user_balance = $user_balance - $cost;
                $new_land_balance = $land_balance + $cost;

                // Update usersignup balance
                $stmt = $con->prepare("UPDATE usersignup SET balance = ? WHERE email = ?");
                $stmt->bind_param("ds", $new_user_balance, $user);
                $stmt->execute();
                $stmt->close();

                // Update land balance
                $stmt = $con->prepare("UPDATE land SET balance = ? WHERE email = ?");
                $stmt->bind_param("di", $new_land_balance, $land);
                $stmt->execute();
                $stmt->close();

                // Update booking table with out_time and calculated cost
                $stmt = $con->prepare("UPDATE booking SET out_time = ?, cost = ? WHERE id = ?");
                $stmt->bind_param("sdi", $out_time, $cost, $id);

                if ($stmt->execute()) {
                    $response = ["status" => "success", "message" => "Booking updated successfully", "cost" => $cost];
                } else {
                    $response = ["status" => "failure", "message" => "Error updating booking"];
                }

                $stmt->close();
            }
        } else {
            $response = ["status" => "failure", "message" => "Booking ID not found"];
        }

        $con->close();
    } else {
        $response = ["status" => "failure", "message" => "Booking ID is required"];
    }

    echo json_encode($response);
}
?>
