<?php
require 'conn.php'; // Ensure database connection

date_default_timezone_set('Asia/Kolkata');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (
        isset($_POST["name"], $_POST["email"], $_POST["password"], $_POST["mobilenumber"], $_POST["slotname"], 
              $_POST["area"], $_POST["no_of_slots_for_bike"], $_POST["no_of_slots_for_car"], 
              $_POST["bike_cost"], $_POST["car_cost"], $_POST["map_link"]) &&
        isset($_FILES["image"], $_FILES["proof"])
    ) {
        // Capture form inputs
        $name = $_POST["name"];
        $email = $_POST["email"];
        $password = $_POST["password"]; // Encrypt password
        $mobilenumber = $_POST["mobilenumber"];
        $slotname = $_POST["slotname"];
        $area = $_POST["area"];
        $no_of_slots_for_bike = $_POST["no_of_slots_for_bike"];
        $no_of_slots_for_car = $_POST["no_of_slots_for_car"];
        $bike_cost = $_POST["bike_cost"];
        $car_cost = $_POST["car_cost"];
        $map_link = $_POST["map_link"];

        if ($con->connect_error) {
            die(json_encode(["status" => "failure", "message" => "Connection failed: " . $con->connect_error]));
        }

        // Insert data into database (excluding images initially)
        $stmt = $con->prepare("INSERT INTO land (name, email, password, mobilenumber, slotname, area, 
                               no_of_slots_for_bike, no_of_slots_for_car, bike_cost, car_cost, map_link) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssiiids", $name, $email, $password, $mobilenumber, $slotname, $area, 
                                     $no_of_slots_for_bike, $no_of_slots_for_car, $bike_cost, $car_cost, $map_link);

        if ($stmt->execute()) {
            $land_id = $stmt->insert_id; // Get inserted ID
            $uploadDir = __DIR__ . '/uploads/';

            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            // Process Image Upload
            $imagePath = $uploadDir . "image_" . $land_id . ".png";
            move_uploaded_file($_FILES["image"]["tmp_name"], $imagePath);
            $imageRelativePath = "uploads/image_" . $land_id . ".png";

            // Process Proof Upload
            $proofPath = $uploadDir . "proof_" . $land_id . ".png";
            move_uploaded_file($_FILES["proof"]["tmp_name"], $proofPath);
            $proofRelativePath = "uploads/proof_" . $land_id . ".png";

            // Update Database with Image Paths
            $updateStmt = $con->prepare("UPDATE land SET image = ?, proof = ? WHERE id = ?");
            $updateStmt->bind_param("ssi", $imageRelativePath, $proofRelativePath, $land_id);
            $updateStmt->execute();

            $response = [
                "status" => "success",
                "message" => "Data inserted successfully",
                "land_id" => $land_id,
                "image_path" => $imageRelativePath,
                "proof_path" => $proofRelativePath
            ];
        } else {
            $response = ["status" => "failure", "message" => "Error inserting data"];
        }

        $stmt->close();
        $updateStmt->close();
        $con->close();
    } else {
        $response = ["status" => "failure", "message" => "All fields and files are required"];
    }

    echo json_encode($response);
}
?>
